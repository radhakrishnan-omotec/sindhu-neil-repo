import pygame
import sys

# Initialize Pygame
pygame.init()

# Set up display
WIDTH, HEIGHT = 800, 700
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Things and Places")
background = pygame.image.load('background.png')

def load_and_resize_image(image_path, size):
    image = pygame.image.load(image_path)
    return pygame.transform.scale(image, size)

#things 
keys = load_and_resize_image(r'keys.jpg',(135, 130))
glasses = load_and_resize_image(r'glasses.jpg',(135, 125))
wallet = load_and_resize_image(r'wallet.jpg',(135, 125))
medicines=load_and_resize_image(r'medicines.jpg',(135, 125))

#Places
k_holder = load_and_resize_image(r"key holder.jpg",(135, 125))
organiser=load_and_resize_image(r'organiser.jpg',(135, 125))
medi_cabinet=load_and_resize_image(r'Medicine-cabinet.jpg',(135,125))
drawer=load_and_resize_image(r'drawer.jpg',(135, 125))


row1 = [keys,glasses,wallet,medicines]
row2 = []  # empty
row3 = [k_holder,organiser,medi_cabinet,drawer]


dragging = False
dragged_image = None
dragged_index = -1

def draw_columns():
    cell_width = 145
    cell_height = 155


    for index, img in enumerate(row1):
        screen.blit(img, (50 + index * cell_width, 50 ))
        #pygame.draw.rect(screen, (0, 0, 0), (100, 50, cell_width, len(row1) * cell_width), 2) 
    
    
    for index, img in enumerate(row2):
        screen.blit(img, (50 + index * cell_width, 200 ))
        #pygame.draw.rect(screen, (0, 0, 0), (100, 200, cell_width, len(row2) * cell_width), 2)

    for index, img in enumerate(row3):
        screen.blit(img, (50 + index * cell_width, 450))
        #pygame.draw.rect(screen, (0, 0, 0), (100, 450, cell_width, len(row3) * cell_width), 2)

def get_image_at_position(x, y):
    # Check if the position (x, y) is over any image in the third row
    for index, img in enumerate(row3):
        img_rect = img.get_rect(bottomleft=(50 + index * 100, 580))
        if img_rect.collidepoint(x, y):
            return index
    return None

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left mouse button
                index = get_image_at_position(event.pos[0], event.pos[1])
                if index is not None:
                    dragging = True
                    dragged_image = row3[index]
                    dragged_index = index

        if event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1 and dragging:
                # Check if dropped in the second column
                if 200 < event.pos[1] < 325:  # Check bounds for second column
                   # print(dragged_index)
                   
                    row2.append(dragged_image)
                    del row3[dragged_index]
                dragging = False
                dragged_image = None
                dragged_index = -1
            for index,img in enumerate(row2):
                print(index,img)
    # Clear the screen
    screen.fill((255, 255, 255))
    screen.blit(background, (0, 0))
    # Draw columns
    draw_columns()


    # Draw dragged image if dragging
    if dragging and dragged_image:
        mouse_x, mouse_y = pygame.mouse.get_pos()
        screen.blit(dragged_image, (mouse_x, mouse_y))

    # Update the display
    pygame.display.flip()
